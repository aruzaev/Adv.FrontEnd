import logo from './logo.svg';
import './App.css';
import Converter from './screens/Converter';

function App() {
  return (
    <div className="App">
      <h1>Artem Ruzaev</h1>
      <h2>n01497403</h2>
      <Converter />
    </div>
  );
}

export default App;
