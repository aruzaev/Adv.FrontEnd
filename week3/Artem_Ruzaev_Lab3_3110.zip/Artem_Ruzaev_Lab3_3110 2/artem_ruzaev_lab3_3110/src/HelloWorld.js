import React, { Component } from "react";
class HelloWorld extends Component {
  render() {
    return (
      <div className="helloContainer">
        <h1>Artem Ruzaev n01497403</h1>
      </div>
    );
  }
}
export default HelloWorld;
