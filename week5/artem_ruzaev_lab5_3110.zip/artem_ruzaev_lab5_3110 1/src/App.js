import logo from "./logo.svg";
import "./App.css";
import MovieList from "./screens/MovieList";

function App() {
  return (
    <div className="App">
      <h1>Artem Ruzaev</h1>
      <h1>n01497403</h1>
      <div className="container">
        <MovieList />
      </div>
    </div>
  );
}

export default App;
