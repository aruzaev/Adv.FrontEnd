import React from 'react';
  
  function ReceiptComponent() {
	return (
	  <div>
	  </div>
	);
  }
  
  export default ReceiptComponent;
  