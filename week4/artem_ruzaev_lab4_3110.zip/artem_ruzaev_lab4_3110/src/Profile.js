const Profile = () => {
  return (
    <div>
      <h1>Artem Ruzaev</h1>
      <h1>n01497403</h1>
    </div>
  );
};

export default Profile;