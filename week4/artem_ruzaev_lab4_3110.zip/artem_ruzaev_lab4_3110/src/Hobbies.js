import React, { Component } from "react";

class Hobbies extends React.Component {
  render() {
    return (
      <div>
        <h2>My Hobbies include:</h2>
        <span>
          <ul>
            <li>Programming</li>
            <li>Reading books</li>
            <li>Watching basketball</li>
            <li>Hanging out with my friends</li>
          </ul>
        </span>
      </div>
    );
  }
}

export default Hobbies;
