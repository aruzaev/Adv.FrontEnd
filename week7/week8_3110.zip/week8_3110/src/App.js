import logo from './logo.svg';
import './App.css';
import Example1 from './screens/Example1';
import Example2 from './screens/Example2';

const App = () => {
  return (
    <div className="App">
      <h1>Week 8 - State Lifting & Prop Drilling</h1>

      <br></br>
      <Example1 />

      <br></br>
      <Example2 />
    </div>
  );
}

export default App;
