import { useState } from "react"
import PetRegistration from "./PetRegistration"
import Pets from "./Pets"

//parent component for PetRegistration & Pets


const Example2 = () => {
    // array of pets
    const [petList, setPetList] = useState([])

    return(
        <div>
            <h2> Example 2 - State Lifting </h2>
            <br/>
            {/* //get the data from child component 
            and save it to state */}
            {/* state lifting - 
            by sending the state and setter function to child component */}
            <PetRegistration 
                petArray = {petList}
                setPetArray = {setPetList} />

            <Pets petArray = {petList} />
        </div>
    )
}

export default Example2