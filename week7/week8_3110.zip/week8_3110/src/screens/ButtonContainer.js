import MyButton from "./MyButton"

//parent component
//receive the parent properties and methods through props
const ButtonContainer = (props) => {
    return(
        <div>
            {/* pass forward the parent method to children component*/}
            <MyButton grandParentMethod = {props.parentMethod} />

            <MyButton grandParentMethod = {props.parentMethod} />

            <MyButton grandParentMethod = {props.parentMethod} />
        </div>
    )
}

export default ButtonContainer