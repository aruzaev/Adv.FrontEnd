import {useState} from "react"

const PetRegistration = (props) => {

    const [petName, setPetName] = useState("")
    const [petAge, setPetAge] = useState(0)

    return(
        <div>
            <h2>Pet Registration </h2>
            <br/><br/>

            <label for="pet_name">Pet Name : </label>
            <input 
            id = "pet_name" 
            type = "text" 
            value={petName}
            onChange={ (e) => {setPetName(e.target.value)} }/>

            <br/>
            <label for="pet_age">Pet Age : </label>
            <input 
            id = "pet_age" 
            type = "number" 
            value={petAge}
            onChange={ (e) => {setPetAge(e.target.value)} }/>

            <br/><br/>
            {/* add the pet information to the array of pets created in Example2 */}
            <button onClick={() => {
                //add a new Pet object into existing array
                //refer to existing array using spread operator (...)
                let newPet = {name: petName, age : petAge}
                props.setPetArray([...props.petArray, newPet])

            }}> Register Pet</button>
        </div>
    )
}

export default PetRegistration