//Grand-child component

//receive the parent properties and methods through props
const MyButton = (props) => {
    return(
        <div>
            <button onClick = {props.grandParentMethod} >Example 1 button </button>
        </div>
    )
}

export default MyButton