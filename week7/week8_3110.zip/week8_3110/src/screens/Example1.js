import ButtonContainer from "./ButtonContainer"

//Grand-Parent component
const Example1 = () => {

    //this method will be supplied to children and grand-children through prop drilling
    const sharedMethod = () => {
        //perform any necessary operation
        alert('It works !')
    }

    return(
        <div>
            <h2>Example 1 - Parent Component</h2>

            {/* supplying the sharedMethod as prop to child component */}
            <ButtonContainer parentMethod = {sharedMethod} />
        </div>
    )
}

export default Example1