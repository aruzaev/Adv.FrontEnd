const Pets = (props) => {
    return(
        <div>
            <h2>Pet List</h2>
            <div>{props.petArray.length} pets are registered with us</div>
        
            {props.petArray.map( (pet) => (
                <div> {pet.name} is {pet.age} years old pet. </div>
            ) )}


        </div>
    )
}

export default Pets