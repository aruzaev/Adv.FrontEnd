import logo from "./logo.svg";
import "./App.css";
import FitnessTracker from "./screens/FitnessTracker";

function App() {
  return (
    <div className="App">
      <FitnessTracker />
    </div>
  );
}

export default App;
